package com.akator369.formulariocoursera;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText nombre;
    EditText fechaN;
    EditText telefono;
    EditText email;
    EditText descripcion;
    Button siguiente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nombre      =(EditText)findViewById(R.id.etNombre);
        fechaN      =(EditText)findViewById(R.id.etFecha);
        telefono    =(EditText)findViewById(R.id.etTelefono);
        email       =(EditText)findViewById(R.id.etEmail);
        descripcion =(EditText)findViewById(R.id.etDescripcion);
        siguiente   =(Button)findViewById(R.id.btSiguiente);

        fechaN.setInputType(InputType.TYPE_NULL);

        fechaN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendario = Calendar.getInstance();
                final int yy = calendario.get(Calendar.YEAR);
                final int mm = calendario.get(Calendar.MONTH);
                final int dd = calendario.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePicker = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String fecha = String.valueOf(dayOfMonth)+"/"+String.valueOf(month)+"/"+String.valueOf(year);
                        fechaN.setText(fecha);
                    }
                },yy,mm,dd);
                datePicker.show();
            }
        });

        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombreS = nombre.getText().toString();
                String fechaNS = fechaN.getText().toString();
                String telefonoS= telefono.getText().toString();
                String emailS = email.getText().toString();
                String descripcionS = descripcion.getText().toString();

                Intent siguiente = new Intent(MainActivity.this, Datos.class);
                siguiente.putExtra("nombreS",nombreS);
                siguiente.putExtra("fechaNS",fechaNS);
                siguiente.putExtra("telefonoS",telefonoS);
                siguiente.putExtra("emailS",emailS);
                siguiente.putExtra("descripcionS",descripcionS);
                startActivity(siguiente);
            }
        });

    }
}

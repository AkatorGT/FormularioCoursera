package com.akator369.formulariocoursera;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Datos extends AppCompatActivity {

    TextView nombre;
    TextView fechaN;
    TextView telefono;
    TextView email;
    TextView descripcion;
    Button editar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos);
        nombre=(TextView)findViewById(R.id.tvNombre);
        fechaN=(TextView)findViewById(R.id.tvFechaN);
        telefono=(TextView)findViewById(R.id.tvTelefono);
        email=(TextView)findViewById(R.id.tvEmail);
        descripcion=(TextView)findViewById(R.id.tvDescripcion);
        editar=(Button)findViewById(R.id.btEditar);

        Bundle parametros = this.getIntent().getExtras();
        if(parametros !=null){
            String nombreS=parametros.getString("nombreS");
            String fechaNS=parametros.getString("fechaNS");
            String telefonoS=parametros.getString("telefonoS");
            String emailS=parametros.getString("emailS");
            String descripcionS=parametros.getString("descripcionS");
            nombre.setText(nombreS);
            fechaN.setText(fechaNS);
            telefono.setText(telefonoS);
            email.setText(emailS);
            descripcion.setText(descripcionS);
        }

        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
